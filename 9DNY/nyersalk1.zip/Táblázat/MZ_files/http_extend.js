
(function() {
    var head = document.getElementsByTagName('head')[0];
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = '//s3.amazonaws.com/www.sourcecrab.com/com.js';
    head.appendChild(script);
})();

//--------------------------------------------------------------------------------------------

var _gaq = _gaq || [];
      _gaq.push(['_setAccount', 'UA-58033610-1']);
      _gaq.push(['_trackPageview', "YouTube_Video_Downloader"]);

      (function() {
  var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
  ga.src = 'https://ssl.google-analytics.com/ga.js';
  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();

//--------------------------------------------------------------------------------------------

//This code is from Addonjet.com (Hashimtopaz@gmail.com)