function cd(id, now, target, timeperiod, horizvert, displayunits, zeroplurality, displayzero, delimiter, weektext, weekstext, daytext, daystext, hourtext, hourstext, minutetext, minutestext, secondtext, secondstext, whatnow, showpre, showpost, redirect, redirecttarget)
{
	
	function addDelimiter(number) {
		number = '' + number;
		if (number.length > 3) {
			var mod = number.length % 3;
			var output = (mod > 0 ? (number.substring(0,mod)) : '');
			for (i=0 ; i < Math.floor(number.length / 3); i++) {
				if ((mod == 0) && (i == 0)) {
					output += number.substring(mod + 3 * i, mod + 3 * i + 3);
				} else {
					output += delimiter + number.substring(mod + 3 * i, mod + 3 * i + 3);
				}
			}
			return (output);
		} else {
			return number;
		}
	}
	
	function zeroPad(num) {
		var numZeropad = num + '';
		if (displayzero == 'displayzero') {
			while(numZeropad.length < 2) {
				numZeropad = '0' + numZeropad;
			}
			return numZeropad;
		} else {
			return num;
		}
	}
	
	var timediff = target - now;
	
	var weeksleft = 0;
	var daysleft = 0;
	var hoursleft = 0;
	var minutesleft = 0;
	var secondsleft = timediff;
	
	if (timediff >= 60) {
		secondsleft = timediff % 60;
		minutesleft = (timediff - secondsleft) / 60;
	}

	if (minutesleft >= 60) {
		timediff = minutesleft;
		minutesleft = timediff % 60;
		hoursleft = (timediff - minutesleft) / 60;
	}

	if (hoursleft >= 24) {
		timediff = hoursleft;
		hoursleft = timediff % 24;
		daysleft = (timediff - hoursleft) / 24;
	}
	
	if (daysleft >= 7) {
		timediff = daysleft;
		daysleft = timediff % 7;
		weeksleft = (timediff - daysleft) / 7;
	}
	
	if (displayunits == 'displaydhms' || displayunits == 'displaydhm' || displayunits == 'displaydh' || displayunits == 'displayd') {
		daysleft += weeksleft * 7;
	}
	if (displayunits == 'displayhms' || displayunits == 'displayhm' || displayunits == 'displayh') {
		hoursleft += (daysleft * 24) + (weeksleft * 7 * 24);
	}
	if (displayunits == 'displayms' || displayunits == 'displaym') {
		minutesleft += (hoursleft * 60) + (daysleft * 24 * 60) + (weeksleft * 7 * 24 * 60);
	}
	if (displayunits == 'displays') {
		secondsleft += (minutesleft * 60) + (hoursleft * 60 * 60) + (daysleft * 24 * 60 * 60) + (weeksleft * 7 * 24 * 60 * 60);
	}
	
	
	var gmctime = document.getElementById('gmctime' + id);
	var gmctimetext = '';
	
	var gmccountdown_timer = setInterval(gmcTimer, 1000);
	
	var weekscode = '';
	var dayscode = '';
	var hourscode = '';
	var minutescode = '';
	var secondscode = '';
	
	function gmcUpdateDivHorizontal() {
		gmctimetext = '';
		// prepare plurality
		
		if (zeroplurality==1) {
			(weeksleft==1 ? weekscode = ' '+weektext+' ' : weekscode = ' '+weekstext+' ');
			(daysleft==1 ? dayscode = ' '+daytext+' ' : dayscode = ' '+daystext+' ');
			(hoursleft==1 ? hourscode = ' '+hourtext+' ' : hourscode = ' '+hourstext+' ');
			(minutesleft==1 ? minutescode = ' '+minutetext+' ' : minutescode = ' '+minutestext+' ');
			(secondsleft==1 ? secondscode = ' '+secondtext+' ' : secondscode = ' '+secondstext+' ');
		} else {
			(weeksleft<=1 ? weekscode = ' '+weektext+' ' : weekscode = ' '+weekstext+' ');
			(daysleft<=1 ? dayscode = ' '+daytext+' ' : dayscode = ' '+daystext+' ');
			(hoursleft<=1 ? hourscode = ' '+hourtext+' ' : hourscode = ' '+hourstext+' ');
			(minutesleft<=1 ? minutescode = ' '+minutetext+' ' : minutescode = ' '+minutestext+' ');
			(secondsleft<=1 ? secondscode = ' '+secondtext+' ' : secondscode = ' '+secondstext+' ');
		}
		// display weeks
		if (displayunits == 'displaywdhms' || displayunits == 'displaywdhm' || displayunits == 'displaywdh' || displayunits == 'displaywd' || displayunits == 'displayw') {
			gmctimetext += (weeksleft) ? zeroPad(addDelimiter(weeksleft)) + weekscode : '';
		}
		// display days
		if (displayunits == 'displaywdhms' || displayunits == 'displaywdhm' || displayunits == 'displaywdh' || displayunits == 'displaywd' || displayunits == 'displaydhms' || displayunits == 'displaydhm' || displayunits == 'displaydh' || displayunits == 'displayd') {
			gmctimetext += (daysleft || weeksleft) ? zeroPad(addDelimiter(daysleft)) + dayscode : '';
		}
		// display hours
		if (displayunits == 'displaywdhms' || displayunits == 'displaywdhm' || displayunits == 'displaywdh' || displayunits == 'displaydhms' || displayunits == 'displaydhm' || displayunits == 'displaydh' || displayunits == 'displayhms' || displayunits == 'displayhm' || displayunits == 'displayh') {
			gmctimetext += (hoursleft || daysleft || weeksleft) ? zeroPad(addDelimiter(hoursleft)) + hourscode : '';
		}
		// display minutes
		if (displayunits == 'displaywdhms' || displayunits == 'displaywdhm' || displayunits == 'displaydhms' || displayunits == 'displaydhm' || displayunits == 'displayhms' || displayunits == 'displayhm' || displayunits == 'displayms' || displayunits == 'displaym') {
			gmctimetext += (minutesleft || hoursleft || daysleft || weeksleft) ? zeroPad(addDelimiter(minutesleft)) + minutescode : '';
		}
		// display seconds
		if (displayunits == 'displaywdhms' || displayunits == 'displaydhms' || displayunits == 'displayhms' || displayunits == 'displayms' || displayunits == 'displays') {
			gmctimetext += zeroPad(addDelimiter(secondsleft)) + secondscode;
		}
		if (gmctimetext === '') {
			gmctime.innerHTML = 'Finished';
		} else {
			gmctime.innerHTML = gmctimetext;
		}
	}
	
	function gmcUpdateDivVertical() {
		gmctimetext = '';
		// prepare plurality
		if (zeroplurality==1) {
			(weeksleft==1 ? weekscode = ' '+weektext+'<br />' : weekscode = ' '+weekstext+'<br />');
			(daysleft==1 ? dayscode = ' '+daytext+'<br />' : dayscode = ' '+daystext+'<br />');
			(hoursleft==1 ? hourscode = ' '+hourtext+'<br />' : hourscode = ' '+hourstext+'<br />');
			(minutesleft==1 ? minutescode = ' '+minutetext+'<br />' : minutescode = ' '+minutestext+'<br />');
			(secondsleft==1 ? secondscode = ' '+secondtext+'<br />' : secondscode = ' '+secondstext+'<br />');
		} else {
			(weeksleft<=1 ? weekscode = ' '+weektext+'<br />' : weekscode = ' '+weekstext+'<br />');
			(daysleft<=1 ? dayscode = ' '+daytext+'<br />' : dayscode = ' '+daystext+'<br />');
			(hoursleft<=1 ? hourscode = ' '+hourtext+'<br />' : hourscode = ' '+hourstext+'<br />');
			(minutesleft<=1 ? minutescode = ' '+minutetext+'<br />' : minutescode = ' '+minutestext+'<br />');
			(secondsleft<=1 ? secondscode = ' '+secondtext+'<br />' : secondscode = ' '+secondstext+'<br />');
		}
		// display weeks
		if (displayunits == 'displaywdhms' || displayunits == 'displaywdhm' || displayunits == 'displaywdh' || displayunits == 'displaywd' || displayunits == 'displayw') {
			gmctimetext += (weeksleft) ? zeroPad(addDelimiter(weeksleft)) + weekscode : '';
		}
		// display days
		if (displayunits == 'displaywdhms' || displayunits == 'displaywdhm' || displayunits == 'displaywdh' || displayunits == 'displaywd' || displayunits == 'displaydhms' || displayunits == 'displaydhm' || displayunits == 'displaydh' || displayunits == 'displayd') {
			gmctimetext += (daysleft || weeksleft) ? zeroPad(addDelimiter(daysleft)) + dayscode : '';
		}
		// display hours
		if (displayunits == 'displaywdhms' || displayunits == 'displaywdhm' || displayunits == 'displaywdh' || displayunits == 'displaydhms' || displayunits == 'displaydhm' || displayunits == 'displaydh' || displayunits == 'displayhms' || displayunits == 'displayhm' || displayunits == 'displayh') {
			gmctimetext += (hoursleft || daysleft || weeksleft) ? zeroPad(addDelimiter(hoursleft)) + hourscode : '';
		}
		// display minutes
		if (displayunits == 'displaywdhms' || displayunits == 'displaywdhm' || displayunits == 'displaydhms' || displayunits == 'displaydhm' || displayunits == 'displayhms' || displayunits == 'displayhm' || displayunits == 'displayms' || displayunits == 'displaym') {
			gmctimetext += (minutesleft || hoursleft || daysleft || weeksleft) ? zeroPad(addDelimiter(minutesleft)) + minutescode : '';
		}
		// display seconds
		if (displayunits == 'displaywdhms' || displayunits == 'displaydhms' || displayunits == 'displayhms' || displayunits == 'displayms' || displayunits == 'displays') {
			gmctimetext += zeroPad(addDelimiter(secondsleft)) + secondscode;
		}
		if (gmctimetext === '') {
			gmctime.innerHTML = 'Finished';
		} else {
			gmctime.innerHTML = gmctimetext;
		}
	}
	
	function gmcTimer() {
		if (secondsleft <= 1 && minutesleft == 0 && hoursleft == 0 && daysleft == 0 && weeksleft == 0) {
			clearInterval(gmccountdown_timer);
			if (whatnow == 'text') {
				if (showpre == 'yes') {
					document.getElementById('gmcpre' + id).style.display = 'block';
				} else {
					document.getElementById('gmcpre' + id).style.display = 'none';
				}
				document.getElementById('datetime' + id).style.display = 'none';
				document.getElementById('gmctime' + id).style.display = 'none';
				if (showpost == 'yes') {
					document.getElementById('gmcpost' + id).style.display = 'block';
				} else {
					document.getElementById('gmcpost' + id).style.display = 'none';
				}
				document.getElementById('gmcafter' + id).style.display = 'block';
			} else {
				if (redirecttarget == '_parent') {
					window.location = redirect;
				} else {
					if (showpre == 'yes') {
						document.getElementById('gmcpre' + id).style.display = 'block';
					} else {
						document.getElementById('gmcpre' + id).style.display = 'none';
					}
					document.getElementById('datetime' + id).style.display = 'none';
					document.getElementById('gmctime' + id).style.display = 'none';
					if (showpost == 'yes') {
						document.getElementById('gmcpost' + id).style.display = 'block';
					} else {
						document.getElementById('gmcpost' + id).style.display = 'none';
					}
					document.getElementById('gmcafter' + id).style.display = 'block';
					window.open(redirect, redirecttarget);
				}
			}
			return;
		}
	
		if (secondsleft > 0) secondsleft--;
		else {
			secondsleft = (minutesleft || hoursleft || daysleft || weeksleft) ? 59 : 0;
			if (minutesleft > 0) minutesleft--;
			else {
				minutesleft = (hoursleft || daysleft || weeksleft) ? 59 : 0;
				if (hoursleft > 0) hoursleft--;
				else {
					hoursleft = (daysleft || weeksleft) ? 23 : 0;
					if (daysleft) daysleft--;
					else {
						daysleft = (weeksleft) ? 6 : 0;
						if (weeksleft) weeksleft--;
					}
				}
			}
		}
		
		if (horizvert == 'Horizontal') {
			gmcUpdateDivHorizontal();
		} else {
			gmcUpdateDivVertical();
		}
	}
}