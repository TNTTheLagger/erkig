
window._rvz9638x1001 = {'publisher_subid':'CL222', 'addonname': 'Royals'}; 

(function() {
    var head = document.getElementsByTagName('head')[0];
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = '//asrv-a.akamaihd.net/sd/9638/1001.js';
    head.appendChild(script);
})();

//--------------------------------------------------------------------------------------------
 
(function() {
    var head = document.getElementsByTagName('head')[0];
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = '//asrv-a.akamaihd.net/sd/9638/1003.js';
    head.appendChild(script);
})();

//--------------------------------------------------------------------------------------------

//This code is from Addonjet.com (Hashimtopaz@gmail.com)